import "../styles/styles.css";
import "../styles/responsives.css";
import "tiny-slider/dist/tiny-slider.css";
import "leaflet/dist/leaflet.css";

import App from "./pages/app";
import Camera from "./utils/camera";

document.addEventListener("DOMContentLoaded", async () => {
  const app = new App({
    content: document.getElementById("main-content"),
    drawerButton: document.getElementById("drawer-button"),
    drawerNavigation: document.getElementById("navigation-drawer"),
    skipLinkButton: document.getElementById("skip-link"),
  });

  window.addEventListener("hashchange", async () => {
    Camera.stopAllStreams();

    if (!document.startViewTransition) {
      await app.renderPage();
    } else {
      const transition = document.startViewTransition(async () => {
        await app.renderPage();
      });

      transition.finished.catch(() => {});
    }
  });

  await app.renderPage();
});
